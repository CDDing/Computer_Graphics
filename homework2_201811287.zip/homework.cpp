
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <math.h>
#include <chrono>
#include <GL/glew.h>
#include <GL/glut.h>
#include <algorithm>
using namespace std;
GLuint transMatrixLoc;
std::chrono::system_clock::time_point starttime;
float kx=0, ky=0, kz=0;
GLuint LoadShaders(const char* vertex_file_path, const char* fragment_file_path)
{
	//create the shaders
	GLuint VertexShaderID = glCreateShader(GL_VERTEX_SHADER);
	GLuint FragmentShaderID = glCreateShader(GL_FRAGMENT_SHADER);

	GLint Result = GL_FALSE;
	int InfoLogLength;

	//Read the vertex shader code from the file
	string VertexShaderCode;
	ifstream VertexShaderStream(vertex_file_path, ios::in);
	if (VertexShaderStream.is_open())
	{
		string Line = "";
		while (getline(VertexShaderStream, Line))
			VertexShaderCode += "\n" + Line;
		VertexShaderStream.close();
	}

	//Compile Vertex Shader
	printf("Compiling shader : %s\n", vertex_file_path);
	char const* VertexSourcePointer = VertexShaderCode.c_str();
	glShaderSource(VertexShaderID, 1, &VertexSourcePointer, NULL);
	glCompileShader(VertexShaderID);

	//Check Vertex Shader
	glGetShaderiv(VertexShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(VertexShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if (InfoLogLength != 0) {
		vector<char> VertexShaderErrorMessage(InfoLogLength);
		glGetShaderInfoLog(VertexShaderID, InfoLogLength, NULL, &VertexShaderErrorMessage[0]);
		fprintf(stdout, "%s\n", &VertexShaderErrorMessage[0]);
	}
	//Read the fragment shader code from the file
	string FragmentShaderCode;
	ifstream FragmentShaderStream(fragment_file_path, ios::in);
	if (FragmentShaderStream.is_open())
	{
		string Line = "";
		while (getline(FragmentShaderStream, Line))
			FragmentShaderCode += "\n" + Line;
		FragmentShaderStream.close();
	}

	//Compile Fragment Shader
	printf("Compiling shader : %s\n", fragment_file_path);
	char const* FragmentSourcePointer = FragmentShaderCode.c_str();
	glShaderSource(FragmentShaderID, 1, &FragmentSourcePointer, NULL);
	glCompileShader(FragmentShaderID);

	//Check Fragment Shader
	glGetShaderiv(FragmentShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(FragmentShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if (InfoLogLength != 0) {
		vector<char> FragmentShaderErrorMessage(InfoLogLength);
		glGetShaderInfoLog(FragmentShaderID, InfoLogLength, NULL, &FragmentShaderErrorMessage[0]);
		fprintf(stdout, "%s\n", &FragmentShaderErrorMessage[0]);
	}
	//Link the program
	fprintf(stdout, "Linking program\n");
	GLuint ProgramID = glCreateProgram();
	glAttachShader(ProgramID, VertexShaderID);
	glAttachShader(ProgramID, FragmentShaderID);
	glLinkProgram(ProgramID);
	GLuint positionAttribute = glGetAttribLocation(ProgramID, "vtxPosition");
	GLuint colorAttribute = glGetAttribLocation(ProgramID, "a_Color");
	transMatrixLoc = glGetUniformLocation(ProgramID, "trans");
	//GLuint transAttribute = glGetUniformLocation(ProgramID, "trans");
	GLuint Buffers[3];
	GLfloat vertices[] = {
		 -0.5f,-0.5f,-0.5f, 
	-0.5f,-0.5f, 0.5f,
	-0.5f, 0.5f, 0.5f,
	0.5f, 0.5f,-0.5f, 
	-0.5f,-0.5f,-0.5f,
	-0.5f, 0.5f,-0.5f,
	0.5f,-0.5f, 0.5f,
	-0.5f,-0.5f,-0.5f,
	0.5f,-0.5f,-0.5f,
	0.5f, 0.5f,-0.5f,
	0.5f,-0.5f,-0.5f,
	-0.5f,-0.5f,-0.5f,
	-0.5f,-0.5f,-0.5f,
	-0.5f, 0.5f, 0.5f,
	-0.5f, 0.5f,-0.5f,
	0.5f,-0.5f, 0.5f,
	-0.5f,-0.5f, 0.5f,
	-0.5f,-0.5f,-0.5f,
	-0.5f, 0.5f, 0.5f,
	-0.5f,-0.5f, 0.5f,
	0.5f,-0.5f, 0.5f,
	0.5f, 0.5f, 0.5f,
	0.5f,-0.5f,-0.5f,
	0.5f, 0.5f,-0.5f,
	0.5f,-0.5f,-0.5f,
	0.5f, 0.5f, 0.5f,
	0.5f,-0.5f, 0.5f,
	0.5f, 0.5f, 0.5f,
	0.5f, 0.5f,-0.5f,
	-0.5f, 0.5f,-0.5f,
	0.5f, 0.5f, 0.5f,
	-0.5f, 0.5f,-0.5f,
	-0.5f, 0.5f, 0.5f,
	0.5f, 0.5f, 0.5f,
	-0.5f, 0.5f, 0.5f,
	0.5f,-0.5f, 0.5f
	};
	GLfloat colors[] = {
		1.0f,1.0f,1.0f,
		1.0f,0.0f,0.0f,
		0.0f,1.0f,0.0f,
		0.0f,0.0f,1.0f,
		0.0f,0.0f,0.0f,
		1.0f,1.0f,0.0f,
		1.0f,0.0f,1.0f,
		0.0f,1.0f,1.0f,
		1.0f,1.0f,1.0f,
		1.0f,0.0f,0.0f,
		0.0f,1.0f,0.0f,
		0.0f,0.0f,1.0f,
		0.0f,0.0f,0.0f,
		1.0f,1.0f,0.0f,
		1.0f,0.0f,1.0f,
		0.0f,1.0f,1.0f,
		1.0f,1.0f,1.0f,
		1.0f,0.0f,0.0f,
		0.0f,1.0f,0.0f,
		0.0f,0.0f,1.0f,
		0.0f,0.0f,0.0f,
		1.0f,1.0f,0.0f,
		1.0f,0.0f,1.0f,
		0.0f,1.0f,1.0f,
		1.0f,1.0f,1.0f,
		1.0f,0.0f,0.0f,
		0.0f,1.0f,0.0f,
		0.0f,0.0f,1.0f,
		0.0f,0.0f,0.0f,
		1.0f,1.0f,0.0f,
		1.0f,0.0f,1.0f,
		0.0f,1.0f,1.0f,
		1.0f,1.0f,1.0f,
		1.0f,0.0f,0.0f,
		0.0f,1.0f,0.0f,
		0.0f,0.0f,1.0f,
	};
	glGenBuffers(2, Buffers);
	glBindBuffer(GL_ARRAY_BUFFER, Buffers[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
	glVertexAttribPointer(positionAttribute, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
	glEnableVertexAttribArray(positionAttribute);

	glBindBuffer(GL_ARRAY_BUFFER, Buffers[1]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(colors), colors, GL_STATIC_DRAW);
	glVertexAttribPointer(colorAttribute, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
	glEnableVertexAttribArray(colorAttribute);

	
	// Check the program
	glGetProgramiv(ProgramID, GL_LINK_STATUS, &Result);
	glGetProgramiv(ProgramID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if (InfoLogLength != 0) {
		vector<char> ProgramErrorMessage(max(InfoLogLength, int(1)));
		glGetProgramInfoLog(ProgramID, InfoLogLength, NULL, &ProgramErrorMessage[0]);
		fprintf(stdout, "%s\n", &ProgramErrorMessage[0]);
	}
	glDeleteShader(VertexShaderID);
	glDeleteShader(FragmentShaderID);

	return ProgramID;
}

GLfloat* getXMatrix(double deg) {
	const double pi = 3.141592;
	double radians = (double)deg * pi / 180.0;
	float sinvalue = sinf(radians);
	float cosvalue = cosf(radians);
	GLfloat* matrix = new GLfloat[16]{
		1.0f,0,0,0,
		0,cosvalue,-sinvalue,0,
		0,sinvalue,cosvalue,0,
		0,0,0,1.0f
	};
	return matrix;
}
GLfloat* getYMatrix(double deg) {
	const double pi = 3.141592;
	double radians = (double)deg * pi / 180.0;
	float sinvalue = sinf(radians);
	float cosvalue = cosf(radians);
	GLfloat* matrix = new GLfloat[16]{
		cosvalue,0,-sinvalue,0,
		0,1,0,0,
		sinvalue,0,cosvalue,0,
		0,0,0,1.0f
	};
	return matrix;
}
GLfloat* getZMatrix(double deg) {
	const double pi = 3.141592;
	double radians = (double)deg * pi / 180.0;
	float sinvalue = sinf(radians);
	float cosvalue = cosf(radians);
	GLfloat* matrix = new GLfloat[16]{
		cosvalue,-sinvalue,0,0,
		sinvalue,cosvalue,0,0,
		0,0,1.0f,0,
		0,0,0,1.0f
	};
	return matrix;
}
GLfloat* gettranslateMatrix(float dx, float dy, float dz) {
	GLfloat* matrix = new GLfloat[16]{
		1.0f,0,0,0,
		0,1.0f,0,0,
		0,0,1.0f,0,
		dx,dy,dz,1.0f,
	};
	return matrix;
}
GLfloat* getScalingMatrix(float dx, float dy, float dz) {
	GLfloat* matrix = new GLfloat[16]{
		dx,0,0,0,
		0,dy,0,0,
		0,0,dz,0,
		0,0,0,1.0f,
	};
	return matrix;
}
void viewMatrix(GLfloat* m) {
	for (int a = 0; a < 4; a++) {
		for (int b = 0; b < 4; b++) {
			printf("%.2f ", m[a * 4 + b]);
		}
		cout << endl;
	}
}
GLfloat* multiplyMatrix(GLfloat* a, GLfloat* b) {
	GLfloat* matrix = new GLfloat[16]{
		0,0,0,0,
		0,0,0,0,
		0,0,0,0,
		0,0,0,0
	};
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			for (int k = 0; k < 4; k++) {
				matrix[i * 4 + j] += a[i * 4 + k] * b[k * 4+j];
			}
		}
	}
	return matrix;
}
void renderScene(void)
{
	//Clear all pixels
	glClearDepth(1.0);
	glDepthFunc(GL_LESS);
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	glEnable(GL_DEPTH_TEST);
	//Let's draw something here

	std::chrono::system_clock::time_point nowtime = std::chrono::system_clock::now();
	std::chrono::milliseconds mili = std::chrono::duration_cast<std::chrono::milliseconds>(nowtime-starttime);
	cout << mili.count()<<endl;
	double milic = mili.count()/10;
	GLfloat* transmatrix = multiplyMatrix(getXMatrix(milic), getYMatrix(milic));
	transmatrix = multiplyMatrix(transmatrix, getScalingMatrix(0.3f,0.3f,0.3f));
	transmatrix = multiplyMatrix(transmatrix, gettranslateMatrix(kx+0.5f, ky, kz));
	/*{
		0.7071f, 0.0f, 0.7071f, 0.0f,
		0.0f, 1.0f, 0.0f, 0.0f,
		-0.7071f, 0.0f, 0.7071f, 0.0f,
		0.0f, 0.0f, 0.0f, 1.0f
	};*/
	glUniformMatrix4fv(transMatrixLoc, 1, GL_FALSE, transmatrix);
	//define the size of point and draw a point.
	glDrawArrays(GL_TRIANGLES, 0, 36);

	transmatrix = multiplyMatrix(getXMatrix(-milic), getYMatrix(milic));
	transmatrix = multiplyMatrix(transmatrix, getScalingMatrix(0.3f, 0.3f, 0.3f));
	transmatrix = multiplyMatrix(transmatrix, gettranslateMatrix(kx-0.5f, ky, kz));
	glUniformMatrix4fv(transMatrixLoc, 1, GL_FALSE, transmatrix);

	glDrawArrays(GL_TRIANGLES, 0, 36);
	//Double buffer
	glutSwapBuffers();
}


void init()
{
	//initilize the glew and check the errors.
	GLenum res = glewInit();
	if (res != GLEW_OK)
	{
		fprintf(stderr, "Error: '%s' \n", glewGetErrorString(res));
	}

	//select the background color
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glEnable(GL_VERTEX_PROGRAM_POINT_SIZE);

}

void doTimer(int i) {
	glutPostRedisplay();
	glutTimerFunc(10, doTimer, 1);
}
void myKeyboard(unsigned char i,int x,int y) {
	if (i == 'q' || i == 'e') {
		ky += 0.1;
	}
	else if (i == 'w' || i == 'r') {
		ky -= 0.1;
	}
	else if (i == 's' ) {
		ky += 0.1;
	}
	else if (i == 'x' ) {
		ky -= 0.1;
	}
	else if (i == 'z' ) {
		kx -= 0.1;
	}
	else if (i == 'c' ) {
		kx += 0.1;
	}
}
int main(int argc, char** argv)
{
	starttime = std::chrono::system_clock::now();
	//init GLUT and create Window
	//initialize the GLUT
	glutInit(&argc, argv);
	//GLUT_DOUBLE enables double buffering (drawing to a background buffer while the other buffer is displayed)
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	//These two functions are used to define the position and size of the window.
	glutInitWindowPosition(200, 200);
	glutInitWindowSize(480, 480);
	//This is used to define the name of the window.
	glutCreateWindow("Simple OpenGL Window");

	//call initization function
	init();

	//1.
	//Generate VAO
	GLuint VertexArrayID;
	glGenVertexArrays(1, &VertexArrayID);
	glBindVertexArray(VertexArrayID);

	//glutMouseFunc(myMouse);
	//3.
	GLuint programID = LoadShaders("VertexShader.txt", "FragmentShader.txt");
	glUseProgram(programID);

	glutDisplayFunc(renderScene);
	glutKeyboardFunc(myKeyboard);
	glutTimerFunc(10, doTimer, 1);
	//enter GLUT event processing cycle
	glutMainLoop();

	glDeleteVertexArrays(1, &VertexArrayID);

	return 1;
}